function initMap() {
    // Initalizing the map
    var map = new google.maps.Map(document.getElementById('map'), {
        center: {
            // Bangalore
            lat: 13.08777,
            lng: 77.6391

            // Hyderabad
            // lat: 17.52551884513851,
            // lng: 78.29294985667735
        },
        zoom: 10
    });

    // Creating an object to draw on the map
    var drawingManager = new google.maps.drawing.DrawingManager({
        // Setting the inital drawing mode
        drawingMode: google.maps.drawing.OverlayType.POLYGON,
        drawingControl: true,
        drawingControlOptions: {
            position: google.maps.ControlPosition.TOP_CENTER,
            drawingModes: [
                google.maps.drawing.OverlayType.POLYGON,
            ]
        },
        polygonOptions: {
            editable: true,
            fillColor: "#fff",
            fillOpacity: 0.3,
            strokeColor: "#000",
            strokeWeight: 3,
        }
    });

    // Set the drawing object on the Map
    drawingManager.setMap(map);

    // Listener for the drawing event
    google.maps.event.addListener(drawingManager, 'overlaycomplete', function (polygon) {
        polygon.overlay.set('editable', false);
        var coordinatesArray = polygon.overlay.getPath().getArray();
        console.log(coordinatesArray)
        console.log(`--- Co-ordinates of the Polygon ---`)
        coordinatesArray.map((coordinates, index) => {
            console.log(`Co-ordinates ${index + 1}: ${coordinates}`)
        })
    });

   
}

initMap();